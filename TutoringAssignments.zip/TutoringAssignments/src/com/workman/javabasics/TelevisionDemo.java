package com.workman.javabasics;

import java.util.Scanner;

public class TelevisionDemo {

	public static void main(String[] args) {
		// Create a Scanner object to read from the keyboard
		Scanner keyboard = new Scanner (System.in);
		// Declare variables
		int station; // The user's channel choice
		// Declare and instantiate a television object
		Television bigScreen = new Television("Toshiba", 55);
		// Turn the power on
		bigScreen.power();
		// Display the state of the television
		System.out.println("A " +
		bigScreen.getScreenSize() +
		" inch " +
		bigScreen.getManufacturer() +
		" has been turned on.");
		// Prompt the user for input and store into station
		System.out.print("What channel do you want? ");
		station = keyboard.nextInt();
		// Change the channel on the television
		bigScreen.setChannel(station);
		// Increase the volume of the television
		bigScreen.increaseVolume(1);
		// Display the the current channel and
		// volume of the television
		System.out.println("Channel: " +
		bigScreen.getChannel() +
		" Volume: " +
		bigScreen.getVolume());
		System.out.println("Too loud! Lowering the volume.");
		// Decrease the volume of the television
		bigScreen.decreaseVolume(1);
		bigScreen.decreaseVolume(1);
		bigScreen.decreaseVolume(1);
		bigScreen.decreaseVolume(1);
		bigScreen.decreaseVolume(1);
		bigScreen.decreaseVolume(1);
		// Display the the current channel and
		// volume of the television
		System.out.println("Channel: " +
		bigScreen.getChannel() +
		" Volume: " +
		bigScreen.getVolume());
		System.out.println(); // For a blank line
		
		// HERE IS WHERE YOU DO TASK #5
		
		Television portable = new Television("Sharp",19);
		portable.power();
		// Display the state of the television
		System.out.println("A " + portable.getScreenSize() + " inch " + portable.getManufacturer() + " has been turned on.");
		
		System.out.print("What channel do you want? ");
		station = keyboard.nextInt();
		portable.setChannel(station);
		portable.decreaseVolume(2);
		System.out.println("Channel: " + portable.getChannel() + " Volume: " + portable.getVolume());
		
	}

}
