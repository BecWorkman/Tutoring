package com.workman.javabasics;

public class Television {
	
	/**
	 * The purpose of this class is to model a television
	 * Becky Workman 12/5/22
	 */
	
	//holds the brand name
	String MANUFACTURER;
	//holds the size of the tv
	int SCREEN_SIZE;
	//hold a t/f value of if the tv is on
	boolean powerOn;
	//hold the value of the station the tv is on
	int channel;
	//holds the loudness of the tv
	int volume;
	
	public Television() {
		
	}
	public Television(String manufacturer, int screenSize) {
	//this constructor takes in two params of manufacturer and screen size along with initializing powerOn, volume and channel to its own values.
		super();
		this.MANUFACTURER = manufacturer;
		this.SCREEN_SIZE = screenSize;
		powerOn = false;
		volume = 20;
		channel = 2;
	}
	
	/**
	 * power() changes the powerOn value from true to false and vice versa
	 */
	public void power() {
		powerOn = !powerOn;
	}
	/**
	 * increaseVolume() increases the volume by one
	 */
	public void increaseVolume(int volume) {
		this.volume += volume;
	}
	/**
	 * decreaseVolume() decreases the volume by one
	 */
	public void decreaseVolume(int volume) {
		this.volume -= volume;
	}

	public String getManufacturer() {
		return MANUFACTURER;
	}


	public void setManufacturer(String manufacturer) {
		MANUFACTURER = manufacturer;
	}


	public int getScreenSize() {
		return SCREEN_SIZE;
	}


	public void setScreenSize(int screenSize) {
		SCREEN_SIZE = screenSize;
	}


	public int getChannel() {
		return channel;
	}


	public int getVolume() {
		return volume;
	}


	public void setChannel(int channel) {
		this.channel = channel;
	}
	
	

}
