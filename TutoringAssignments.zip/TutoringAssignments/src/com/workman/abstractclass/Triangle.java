package com.workman.abstractclass;

import java.util.Scanner;

public class Triangle extends GeometricObject{

	
	
	public Triangle() {
		// TODO Auto-generated constructor stub
	}


	public void findTrianglePerimeter() {
		perimeter = getSideOne() + getSideTwo() + getSideThree();
		System.out.println("Triangle's Perimeter: " + perimeter);
	}
	public void findTriangleArea() {
		int p = 0;
		int area = 0;
		
		perimeter = getSideOne() + getSideTwo() + getSideThree();
		p = perimeter/2;
		area = (p*(p-getSideOne()) * (p-getSideTwo()) * (p-getSideThree()));
		System.out.println("Triangle's Area: " + area);
		
	}
	public void displayColor() {
		System.out.println("Triangle's Color : " + getColor());
	}
	public void displayFilled() {
		System.out.println("Is the triangle filled? " + isBackground());
	}


	@Override
	public void maxOfShape(int x, int y) {
		System.out.println("The max is: " + Math.max(x, y));
		
	}


}
