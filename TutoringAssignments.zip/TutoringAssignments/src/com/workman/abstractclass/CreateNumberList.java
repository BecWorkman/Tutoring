package com.workman.abstractclass;

import java.util.ArrayList;
import java.util.Collections;

public class CreateNumberList {
	
	public static void sortList() {
		//Sort ArrayList
		ArrayList <Integer> myNumbers = new ArrayList<Integer>();
		
		myNumbers.add(100);
		myNumbers.add(50);
		myNumbers.add(150);
		myNumbers.add(10);
		myNumbers.add(1);
		
		Collections.sort(myNumbers);
		System.out.println(myNumbers);
	}

}
