package com.workman.abstractclass;

public class Circle extends GeometricObject{
	
	private double radius;
	
	public Circle() {
		
	}
	

	public Circle(int radius, String color, boolean filled) {
		super();
		this.radius = radius;
		setColor(color);
		setBackground(filled);
	}


	public double getRadius() {
		return radius;
	}


	public void setRadius(double radius) {
		this.radius = radius;
	}


	@Override
	public void findPerimeter() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double findArea() {
		return radius * radius * Math.PI;
		
	}

	@Override
	public void displayColor() {
		System.out.println("Circle's Color : " + getColor());
		
	}

	@Override
	public void displayFilled() {
		System.out.println("Is the circle filled? " + isBackground());
		
	}
	
	

}
