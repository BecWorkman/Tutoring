package com.workman.abstractclass;

import java.util.ArrayList;
import java.util.Scanner;

public class ShapeDriver {

	public static void main(String[] args) {
		
//		GeometricObject obj = new Triangle();
//		
//		Scanner input = new Scanner(System.in);
//		
//		
//		System.out.println("Enter side one's lengh: ");
//		obj.sideOne = input.nextInt();
//		
//		System.out.println("Enter side two's lengh: ");
//		obj.sideTwo = input.nextInt();
//		
//		System.out.println("Enter side three's lengh: ");
//		obj.sideThree = input.nextInt();
//		
//		System.out.println("Enter the triangles color: ");
//		obj.color = input.next();
//		
//		System.out.println("Is the triangle filled? (true/false) ");
//		obj.background = input.nextBoolean();
		
//		obj.findTriangleArea();
//		obj.findTrianglePerimeter();
//		obj.displayColor();
//		obj.displayFilled();
		
		//Sort ArrayList
//		CreateNumberList numList = new CreateNumberList();
//		numList.sortList();
		
		GeometricObject obj = new Triangle();

		obj.maxOfShape(10, 20);
		obj.maxOfShape(500, 300);
		

	}
	

}
