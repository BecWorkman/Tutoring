package com.workman.abstractclass;

public interface Comparable{
	
	void maxOfShape(int x, int y);

}
