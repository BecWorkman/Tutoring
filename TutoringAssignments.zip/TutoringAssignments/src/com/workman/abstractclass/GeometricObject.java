package com.workman.abstractclass;

 public abstract class GeometricObject implements Comparable{
	
	protected int sideOne;
	protected int sideTwo;
	protected int sideThree;
	protected String color;
	protected boolean background;
	protected int perimeter;



	public abstract void findTrianglePerimeter();
	public abstract void findTriangleArea();
	public abstract void displayColor();
	public abstract void displayFilled();
	
	public void maxOfShape(int t1, int t2) {
	
		System.out.println("The max is: " + Math.max(t1, t2));
		
	}


	public int getSideOne() {
		return sideOne;
	}


	public void setSideOne(int sideOne) {
		this.sideOne = sideOne;
	}


	public int getSideTwo() {
		return sideTwo;
	}


	public void setSideTwo(int sideTwo) {
		this.sideTwo = sideTwo;
	}


	public int getSideThree() {
		return sideThree;
	}


	public void setSideThree(int sideThree) {
		this.sideThree = sideThree;
	}


	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}


	public boolean isBackground() {
		return background;
	}


	public void setBackground(boolean background) {
		this.background = background;
	}


	public int getPerimeter() {
		return perimeter;
	}


	public void setPerimeter(int perimeter) {
		this.perimeter = perimeter;
	}
	
	

}
