package com.workman.stringbuffer;

public class MyStringBuilder {
	
	public MyStringBuilder() {
		
	}
	
	public MyStringBuilder(String s) {
		StringBuilder str = new StringBuilder(s);
		System.out.println(str);
	}
	public void append(String s) {
		StringBuilder str = new StringBuilder(s);
		str.append(" World!");
		System.out.println(str);
	}
	public void append(int i) {
		StringBuilder str = new StringBuilder("My number is: ");
		Integer number = i;
		str.append(number);
		System.out.println(str);
	}
	public void findLength(String s) {
		System.out.println(s.length());
	}
	public void charAt(String s) {
		StringBuilder str = new StringBuilder(s);
		System.out.println(str.charAt(2));
	}
	public void toLowerCase(String s) {
		System.out.println(s.toLowerCase());
	}
	public void substringExample(String s) {
		System.out.println(s.substring(9, 12));
	}
	public void convertToString(String s) {
		StringBuilder str = new StringBuilder(s);
		System.out.println(str.toString());
		
	}

}
