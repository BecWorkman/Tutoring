package com.workman.stringbuffer;

public class StringBufferDriver {
	

	public static void main(String[] args) {
		/**
		 * 
		 * 1. StringBuffer is synchronized where as String Builder isn't. Making StringBuilder faster than StringBuffer
		 * 2. To create a string builder from a string you have to create a string builder object accepting a string 
		 * 	  parameter. To return the string you have to System.out.print the object with the .toString() method.
		 * 	  StringBuilder str = new StringBuilder("String");
		 *	  System.out.println(str.toString());
		 * 5. The internal storage for characters in a string is within a string constant pool. Where as the StringBuilder 
		 * 	  objects are located in the heap.
		 */
		
//		questionThree("Reversing Strings is fun!");
//		questionThree("Wow");
//		questionThree("Cool Beans!");
//		
//		questionFour("Welcome to Java Core!");
//		questionFour("Hey... can you keep a secret?");
//		questionFour("Ready to hear a secret? It's a good one");
//
//		questionSix("Java","HTML");
		
		MyStringBuilder obj = new MyStringBuilder("Five");
		MyStringBuilder obj2 = new MyStringBuilder();
		obj.toString();
		obj2.append("Hello");
		obj2.append(1);
		obj2.findLength("Becky");
		obj2.charAt("Justin");
		obj2.toLowerCase("CODING IS FUN");
		obj2.substringExample("Monsters are cool!");
		obj2.convertToString("Mondays are the worst");

	}
	
	public static void questionThree(String s) {
		StringBuilder str = new StringBuilder(s);
		str.reverse();
		System.out.println("Reversed String: " + str.toString());
		
	}
	
	public static void 	questionFour(String msg) {
		StringBuilder newMsg = new StringBuilder(msg);
		newMsg.delete(4, 10);
		System.out.println("New Deleted Message: " + newMsg.toString());
	}
	
	public static void questionSix(String s1, String s2) {
		StringBuilder newS1 = new StringBuilder(s1);
		StringBuilder newS2 = new StringBuilder(s2);
		
		newS1.append(" is fun ");
		System.out.println(newS1);
		newS1.append(s2);
		System.out.println(newS1);
	}

}
